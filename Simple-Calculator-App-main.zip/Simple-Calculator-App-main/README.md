# Simple-Calculator-App
![Screenshot 2023-02-18 at 10 08 16 PM](https://user-images.githubusercontent.com/122967322/220820124-7246d38f-1cb7-44d3-885e-67f12167efd2.png)
