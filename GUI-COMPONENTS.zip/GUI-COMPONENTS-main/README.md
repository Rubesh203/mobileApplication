# GUI-COMPONENTS
Develop an application to change the font and color of the text and display toast message when the user presses the button. 
